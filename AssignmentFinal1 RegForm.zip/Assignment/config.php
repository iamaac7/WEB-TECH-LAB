<?php

$conn= mysqli_connect('localhost','root','','assignment');

//Write at least 2 functions for open and close connection to database.
?>